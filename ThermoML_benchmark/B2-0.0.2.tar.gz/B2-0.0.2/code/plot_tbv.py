#!/usr/bin/env python
import numpy as np
import simtk.unit as u
import polarizability
import matplotlib
matplotlib.use('Agg')  # noqa
import matplotlib.pyplot as plt
import pandas as pd
import fire
from scipy.stats import linregress

from density_simulation_parameters import (FF_NAME)

# Statistics code copied/stolen from `FreeSolv` directory here (author Andrea Rizzi)
def compute_sample_statistics(x, y):
    slope, intercept, r_value, p_value, stderr = linregress(x, y)
    diff = np.array(x) - np.array(y)
    avg_err = diff.mean()
    rms_err = np.sqrt((diff**2).mean())
    return np.array([r_value, avg_err, rms_err])

# Statistics code copied/stolen from `FreeSolv` directory here (author Andrea Rizzi)
def compute_bootstrap_statistics(x, y, percentile=0.95, n_bootstrap_samples=5000):
    """Compute R, mean error and RMSE for the data with bootstrap confidence interval."""
    x = np.array(x)
    y = np.array(y)
    statistics = compute_sample_statistics(x, y)

    # Generate bootstrap statistics variations.
    statistics_samples_diff = np.zeros((n_bootstrap_samples, len(statistics)))
    for i in range(n_bootstrap_samples):
        bootstrap_sample_indices = np.random.randint(low=0, high=len(x), size=len(x))
        x_bootstrap = x[bootstrap_sample_indices]
        y_bootstrap = y[bootstrap_sample_indices]
        statistics_samples_diff[i] = compute_sample_statistics(x_bootstrap, y_bootstrap)

    # Compute confidence intervals.
    stat_bound_id = int(np.floor(n_bootstrap_samples * (1 - percentile) / 2)) - 1
    statistics_confidence_intervals = []
    for i, stat_samples_diff in enumerate(statistics_samples_diff.T):
        stat_samples_diff.sort()
        stat_lower_bound = stat_samples_diff[stat_bound_id]
        stat_higher_bound = stat_samples_diff[-stat_bound_id+1]
        statistics_confidence_intervals.append([statistics[i], (stat_lower_bound, stat_higher_bound)])

    return statistics_confidence_intervals

def runner(expt_csv, pred_csv, dens_pdf, diff_pdf, diel_pdf, nocorr_pdf):
    FIGURE_SIZE = (6.5, 6.5)
    DPI = 1600

    expt = pd.read_csv(expt_csv)
    expt["temperature"] = expt["Temperature, K"]

    pred = pd.read_csv(pred_csv)
    pred["polcorr"] = pd.Series(dict((cas, polarizability.dielectric_correction_from_formula(formula, density * u.grams / u.milliliter)) for cas, (formula, density) in pred[["formula", "density"]].iterrows()))
    pred["corrected_dielectric"] = pred["polcorr"] + pred["dielectric"]

    expt = expt.set_index(["cas", "temperature"])  # Can't do this because of duplicates  # Should be fixed now, probably due to the CAS / name duplication issue found by Julie.
    pred = pred.set_index(["cas", "temperature"])

    pred["expt_density"] = expt["Mass density, kg/m3"]
    pred["expt_dielectric"] = expt["Relative permittivity at zero frequency"]
    pred["expt_density_std"] = expt["Mass density, kg/m3_uncertainty_bestguess"]
    pred["expt_dielectric_std"] = expt["Relative permittivity at zero frequency_uncertainty_bestguess"]

    plt.figure(figsize=FIGURE_SIZE, dpi=DPI)

    xvals = []
    dxvals = []
    yvals = []
    dyvals = []
    for (formula, grp) in pred.groupby("formula"):
        x, y = grp["density"], grp["expt_density"]
        xerr = grp["density_sigma"]
        yerr = grp["expt_density_std"].replace(np.nan, 0.0)
        x = x / 1000.  # Convert kg / m3 to g / mL
        y = y / 1000.  # Convert kg / m3 to g / mL
        xerr = xerr / 1000.  # Convert kg / m3 to g / mL
        yerr = yerr / 1000.  # Convert kg / m3 to g / mL
        plt.errorbar(x, y, xerr=xerr, yerr=yerr, fmt='.', label=formula)
        for entry in x: xvals.append(entry)
        for entry in y: yvals.append(entry)
        for entry in xerr: dxvals.append(entry)
        for entry in yerr: dyvals.append(entry)

    bootstrap_statistics = compute_bootstrap_statistics(xvals, yvals)
    r_value, r_value_interval = bootstrap_statistics[0]
    avg_err, avg_err_interval = bootstrap_statistics[1]
    rms_err, rms_err_interval = bootstrap_statistics[2]

    statistics_msg = ("R$^2$:      {:.3f} [ {:.3f},  {:.3f}]\n"
                      "ME:  {:.3f} [{:.3f}, {:.3f}] kcal/mol\n"
                      "RMSE: {:.3f} [ {:.3f},  {:.3f}] kcal/mol")
    statistics_msg = statistics_msg.format(
        r_value**2, r_value_interval[0]**2, r_value_interval[1]**2,
        avg_err, avg_err_interval[0], avg_err_interval[1],
        rms_err, rms_err_interval[0], rms_err_interval[1])

    plt.plot([.600, 1.400], [.600, 1.400], 'k', linewidth=1)
    plt.xlim((.600, 1.400))
    plt.ylim((.600, 1.400))
    plt.xlabel("Predicted (%s)" % FF_NAME)
    plt.ylabel("Experiment (ThermoML)")
    plt.gca().set_aspect('equal', adjustable='box')
    # Add grid
    plt.gca().grid(axis='both', linestyle="--", lw=0.5, color="black", alpha=0.2)
    # Add statistics message
    plt.gca().text(0.02, 0.9, statistics_msg, transform=plt.gca().transAxes)
    plt.draw()

    x, y = pred["density"], pred["expt_density"]
    plt.title(r"Density [g cm$^{-3}$]")
    plt.savefig(dens_pdf, bbox_inches="tight")

    plt.figure(figsize=FIGURE_SIZE, dpi=DPI)
    xvals = []
    dxvals = []
    yvals = []
    dyvals = []
    for (formula, grp) in pred.groupby("formula"):
        x, y = grp["density"], grp["expt_density"]
        xerr = grp["density_sigma"]
        yerr = grp["expt_density_std"].replace(np.nan, 0.0)
        x = x / 1000.  # Convert kg / m3 to g / mL
        y = y / 1000.  # Convert kg / m3 to g / mL
        xerr = xerr / 1000.  # Convert kg / m3 to g / mL
        yerr = yerr / 1000.  # Convert kg / m3 to g / mL
        plt.errorbar(x - y, y, xerr=xerr, yerr=yerr, fmt='.', label=formula)
        for entry in x: xvals.append(entry)
        for entry in y: yvals.append(entry)
        for entry in xerr: dxvals.append(entry)
        for entry in yerr: dyvals.append(entry)

    bootstrap_statistics = compute_bootstrap_statistics(xvals, yvals)
    r_value, r_value_interval = bootstrap_statistics[0]
    avg_err, avg_err_interval = bootstrap_statistics[1]
    rms_err, rms_err_interval = bootstrap_statistics[2]

    statistics_msg = ("R$^2$:      {:.3f} [ {:.3f},  {:.3f}]\n"
                      "MD:  {:.3f} [{:.3f}, {:.3f}] kcal/mol\n"
                      "RMSD: {:.3f} [ {:.3f},  {:.3f}] kcal/mol")
    statistics_msg = statistics_msg.format(
        r_value**2, r_value_interval[0]**2, r_value_interval[1]**2,
        avg_err, avg_err_interval[0], avg_err_interval[1],
        rms_err, rms_err_interval[0], rms_err_interval[1])

    plt.xlim((-0.1, 0.1))
    plt.ylim((.600, 1.400))
    plt.xlabel("Predicted - Experiment")
    plt.ylabel("Experiment (ThermoML)")
    plt.gca().set_aspect('auto', adjustable='box')
    # Add grid
    plt.gca().grid(axis='both', linestyle="--", lw=0.5, color="black", alpha=0.2)
    plt.gca().text(0.02, 0.9, statistics_msg, transform=plt.gca().transAxes)
    plt.draw()

    x, y = pred["density"], pred["expt_density"]
    plt.title(r"Density [g cm$^{-3}$]")

    plt.savefig(diff_pdf, bbox_inches="tight")

    yerr = pred["expt_dielectric_std"].replace(np.nan, 0.0)
    xerr = pred["dielectric_sigma"].replace(np.nan, 0.0)

    plt.figure(figsize=FIGURE_SIZE, dpi=DPI)

    plt.xlabel("Predicted (%s)" % FF_NAME)
    plt.ylabel("Experiment (ThermoML)")
    plt.title("Inverse Static Dielectric Constant")

    plt.plot([0.0, 1], [0.0, 1], 'k')  # Guide

    x, y = pred["dielectric"], pred["expt_dielectric"]
    plt.errorbar(x ** -1, y ** -1, xerr=xerr * x ** -2, yerr=yerr * y ** -2, fmt='.', label=FF_NAME)  # Transform xerr and yerr for 1 / epsilon plot


    bootstrap_statistics = compute_bootstrap_statistics(x**-1, y**-1)
    r_value, r_value_interval = bootstrap_statistics[0]
    avg_err, avg_err_interval = bootstrap_statistics[1]
    rms_err, rms_err_interval = bootstrap_statistics[2]

    statistics_msg = ("SMIRNOFF:\nR$^2$:      {:.3f} [ {:.3f},  {:.3f}]\n"
                      "ME:  {:.3f} [{:.3f}, {:.3f}] kcal/mol\n"
                      "RMSE: {:.3f} [ {:.3f},  {:.3f}] kcal/mol")
    statistics_msg = statistics_msg.format(
        r_value**2, r_value_interval[0]**2, r_value_interval[1]**2,
        avg_err, avg_err_interval[0], avg_err_interval[1],
        rms_err, rms_err_interval[0], rms_err_interval[1])

    plt.xlim((0.0, 1))
    plt.ylim((0.0, 1))
    plt.legend(loc=0)
    plt.gca().set_aspect('equal', adjustable='box')
    # Add grid
    plt.gca().grid(axis='both', linestyle="--", lw=0.5, color="black", alpha=0.2)
    # Add statistics message
    plt.gca().text(0.02, 0.75, statistics_msg, transform=plt.gca().transAxes)
    plt.draw()
    plt.savefig(nocorr_pdf, bbox_inches="tight")

    x, y = pred["corrected_dielectric"], pred["expt_dielectric"]
    plt.errorbar(x ** -1, y ** -1, xerr=xerr * x ** -2, yerr=yerr * y ** -2, fmt='.', label="Corrected")  # Transform xerr and yerr for 1 / epsilon plot

    bootstrap_statistics = compute_bootstrap_statistics(x**-1, y**-1)
    r_value, r_value_interval = bootstrap_statistics[0]
    avg_err, avg_err_interval = bootstrap_statistics[1]
    rms_err, rms_err_interval = bootstrap_statistics[2]

    statistics_msg = ("Corrected:\nR$^2$:      {:.3f} [ {:.3f},  {:.3f}]\n"
                      "ME:  {:.3f} [{:.3f}, {:.3f}] kcal/mol\n"
                      "RMSE: {:.3f} [ {:.3f},  {:.3f}] kcal/mol")
    statistics_msg = statistics_msg.format(
        r_value**2, r_value_interval[0]**2, r_value_interval[1]**2,
        avg_err, avg_err_interval[0], avg_err_interval[1],
        rms_err, rms_err_interval[0], rms_err_interval[1])

    plt.xlim((0.0, 1.02))
    plt.ylim((0.0, 1.02))
    plt.legend(loc=0)
    plt.gca().set_aspect('equal', adjustable='box')
    # Add grid
    plt.gca().grid(axis='both', linestyle="--", lw=0.5, color="black", alpha=0.2)
    plt.gca().text(0.02, 0.6, statistics_msg, transform=plt.gca().transAxes)
    plt.draw()
    plt.savefig(diel_pdf, bbox_inches="tight")


if __name__ == "__main__":
    fire.Fire(runner)
